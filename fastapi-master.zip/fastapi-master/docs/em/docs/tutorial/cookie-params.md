# 🍪 🔢

👆 💪 🔬 🍪 🔢 🎏 🌌 👆 🔬 `Query` &amp; `Path` 🔢.

## 🗄 `Cookie`

🥇 🗄 `Cookie`:

{* ../../docs_src/cookie_params/tutorial001.py hl[3] *}

## 📣 `Cookie` 🔢

⤴️ 📣 🍪 🔢 ⚙️ 🎏 📊 ⏮️ `Path` &amp; `Query`.

🥇 💲 🔢 💲, 👆 💪 🚶‍♀️ 🌐 ➕ 🔬 ⚖️ ✍ 🔢:

{* ../../docs_src/cookie_params/tutorial001.py hl[9] *}

/// note | 📡 ℹ

`Cookie` "👭" 🎓 `Path` &amp; `Query`. ⚫️ 😖 ⚪️➡️ 🎏 ⚠ `Param` 🎓.

✋️ 💭 👈 🕐❔ 👆 🗄 `Query`, `Path`, `Cookie` &amp; 🎏 ⚪️➡️ `fastapi`, 👈 🤙 🔢 👈 📨 🎁 🎓.

///

/// info

📣 🍪, 👆 💪 ⚙️ `Cookie`, ↩️ ⏪ 🔢 🔜 🔬 🔢 🔢.

///

## 🌃

📣 🍪 ⏮️ `Cookie`, ⚙️ 🎏 ⚠ ⚓ `Query` &amp; `Path`.
