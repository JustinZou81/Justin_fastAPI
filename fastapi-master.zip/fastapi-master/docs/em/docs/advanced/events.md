# 🔆 🎉

👆 💪 🔬 ⚛ (📟) 👈 🔜 🛠️ ⏭ 🈸 **▶️ 🆙**. 👉 ⛓ 👈 👉 📟 🔜 🛠️ **🕐**, **⏭** 🈸 **▶️ 📨 📨**.

🎏 🌌, 👆 💪 🔬 ⚛ (📟) 👈 🔜 🛠️ 🕐❔ 🈸 **🤫 🔽**. 👉 💼, 👉 📟 🔜 🛠️ **🕐**, **⏮️** ✔️ 🍵 🎲 **📚 📨**.

↩️ 👉 📟 🛠️ ⏭ 🈸 **▶️** ✊ 📨, &amp; ▶️️ ⏮️ ⚫️ **🏁** 🚚 📨, ⚫️ 📔 🎂 🈸 **🔆** (🔤 "🔆" 🔜 ⚠ 🥈 👶).

👉 💪 📶 ⚠ ⚒ 🆙 **ℹ** 👈 👆 💪 ⚙️ 🎂 📱, &amp; 👈 **💰** 👪 📨, &amp;/⚖️ 👈 👆 💪 **🧹 🆙** ⏮️. 🖼, 💽 🔗 🎱, ⚖️ 🚚 🔗 🎰 🏫 🏷.

## ⚙️ 💼

➡️ ▶️ ⏮️ 🖼 **⚙️ 💼** &amp; ⤴️ 👀 ❔ ❎ ⚫️ ⏮️ 👉.

➡️ 🌈 👈 👆 ✔️ **🎰 🏫 🏷** 👈 👆 💚 ⚙️ 🍵 📨. 👶

🎏 🏷 🔗 👪 📨,, ⚫️ 🚫 1️⃣ 🏷 📍 📨, ⚖️ 1️⃣ 📍 👩‍💻 ⚖️ 🕳 🎏.

➡️ 🌈 👈 🚚 🏷 💪 **✊ 🕰**, ↩️ ⚫️ ✔️ ✍ 📚 **💽 ⚪️➡️ 💾**. 👆 🚫 💚 ⚫️ 🔠 📨.

👆 💪 📐 ⚫️ 🔝 🎚 🕹/📁, ✋️ 👈 🔜 ⛓ 👈 ⚫️ 🔜 **📐 🏷** 🚥 👆 🏃‍♂ 🙅 🏧 💯, ⤴️ 👈 💯 🔜 **🐌** ↩️ ⚫️ 🔜 ✔️ ⌛ 🏷 📐 ⏭ 💆‍♂ 💪 🏃 🔬 🍕 📟.

👈 ⚫️❔ 👥 🔜 ❎, ➡️ 📐 🏷 ⏭ 📨 🍵, ✋️ 🕴 ▶️️ ⏭ 🈸 ▶️ 📨 📨, 🚫 ⏪ 📟 ➖ 📐.

## 🔆

👆 💪 🔬 👉 *🕴* &amp; *🤫* ⚛ ⚙️ `lifespan` 🔢 `FastAPI` 📱, &amp; "🔑 👨‍💼" (👤 🔜 🎦 👆 ⚫️❔ 👈 🥈).

➡️ ▶️ ⏮️ 🖼 &amp; ⤴️ 👀 ⚫️ ℹ.

👥 ✍ 🔁 🔢 `lifespan()` ⏮️ `yield` 💖 👉:

{* ../../docs_src/events/tutorial003.py hl[16,19] *}

📥 👥 ⚖ 😥 *🕴* 🛠️ 🚚 🏷 🚮 (❌) 🏷 🔢 📖 ⏮️ 🎰 🏫 🏷 ⏭ `yield`. 👉 📟 🔜 🛠️ **⏭** 🈸 **▶️ ✊ 📨**, ⏮️ *🕴*.

&amp; ⤴️, ▶️️ ⏮️ `yield`, 👥 🚚 🏷. 👉 📟 🔜 🛠️ **⏮️** 🈸 **🏁 🚚 📨**, ▶️️ ⏭ *🤫*. 👉 💪, 🖼, 🚀 ℹ 💖 💾 ⚖️ 💻.

/// tip

`shutdown` 🔜 🔨 🕐❔ 👆 **⛔️** 🈸.

🎲 👆 💪 ▶️ 🆕 ⏬, ⚖️ 👆 🤚 🎡 🏃 ⚫️. 🤷

///

### 🔆 🔢

🥇 👜 👀, 👈 👥 ⚖ 🔁 🔢 ⏮️ `yield`. 👉 📶 🎏 🔗 ⏮️ `yield`.

{* ../../docs_src/events/tutorial003.py hl[14:19] *}

🥇 🍕 🔢, ⏭ `yield`, 🔜 🛠️ **⏭** 🈸 ▶️.

&amp; 🍕 ⏮️ `yield` 🔜 🛠️ **⏮️** 🈸 ✔️ 🏁.

### 🔁 🔑 👨‍💼

🚥 👆 ✅, 🔢 🎀 ⏮️ `@asynccontextmanager`.

👈 🗜 🔢 🔘 🕳 🤙 "**🔁 🔑 👨‍💼**".

{* ../../docs_src/events/tutorial003.py hl[1,13] *}

**🔑 👨‍💼** 🐍 🕳 👈 👆 💪 ⚙️ `with` 📄, 🖼, `open()` 💪 ⚙️ 🔑 👨‍💼:

```Python
with open("file.txt") as file:
    file.read()
```

⏮️ ⏬ 🐍, 📤 **🔁 🔑 👨‍💼**. 👆 🔜 ⚙️ ⚫️ ⏮️ `async with`:

```Python
async with lifespan(app):
    await do_stuff()
```

🕐❔ 👆 ✍ 🔑 👨‍💼 ⚖️ 🔁 🔑 👨‍💼 💖 🔛, ⚫️❔ ⚫️ 🔨 👈, ⏭ 🛬 `with` 🍫, ⚫️ 🔜 🛠️ 📟 ⏭ `yield`, &amp; ⏮️ ❎ `with` 🍫, ⚫️ 🔜 🛠️ 📟 ⏮️ `yield`.

👆 📟 🖼 🔛, 👥 🚫 ⚙️ ⚫️ 🔗, ✋️ 👥 🚶‍♀️ ⚫️ FastAPI ⚫️ ⚙️ ⚫️.

`lifespan` 🔢 `FastAPI` 📱 ✊ **🔁 🔑 👨‍💼**, 👥 💪 🚶‍♀️ 👆 🆕 `lifespan` 🔁 🔑 👨‍💼 ⚫️.

{* ../../docs_src/events/tutorial003.py hl[22] *}

## 🎛 🎉 (😢)

/// warning

👍 🌌 🍵 *🕴* &amp; *🤫* ⚙️ `lifespan` 🔢 `FastAPI` 📱 🔬 🔛.

👆 💪 🎲 🚶 👉 🍕.

///

📤 🎛 🌌 🔬 👉 ⚛ 🛠️ ⏮️ *🕴* &amp; ⏮️ *🤫*.

👆 💪 🔬 🎉 🐕‍🦺 (🔢) 👈 💪 🛠️ ⏭ 🈸 ▶️ 🆙, ⚖️ 🕐❔ 🈸 🤫 🔽.

👫 🔢 💪 📣 ⏮️ `async def` ⚖️ 😐 `def`.

### `startup` 🎉

🚮 🔢 👈 🔜 🏃 ⏭ 🈸 ▶️, 📣 ⚫️ ⏮️ 🎉 `"startup"`:

{* ../../docs_src/events/tutorial001.py hl[8] *}

👉 💼, `startup` 🎉 🐕‍🦺 🔢 🔜 🔢 🏬 "💽" ( `dict`) ⏮️ 💲.

👆 💪 🚮 🌅 🌘 1️⃣ 🎉 🐕‍🦺 🔢.

&amp; 👆 🈸 🏆 🚫 ▶️ 📨 📨 ⏭ 🌐 `startup` 🎉 🐕‍🦺 ✔️ 🏁.

### `shutdown` 🎉

🚮 🔢 👈 🔜 🏃 🕐❔ 🈸 🤫 🔽, 📣 ⚫️ ⏮️ 🎉 `"shutdown"`:

{* ../../docs_src/events/tutorial002.py hl[6] *}

📥, `shutdown` 🎉 🐕‍🦺 🔢 🔜 ✍ ✍ ⏸ `"Application shutdown"` 📁 `log.txt`.

/// info

`open()` 🔢, `mode="a"` ⛓ "🎻",, ⏸ 🔜 🚮 ⏮️ ⚫️❔ 🔛 👈 📁, 🍵 📁 ⏮️ 🎚.

///

/// tip

👀 👈 👉 💼 👥 ⚙️ 🐩 🐍 `open()` 🔢 👈 🔗 ⏮️ 📁.

, ⚫️ 🔌 👤/🅾 (🔢/🔢), 👈 🚚 "⌛" 👜 ✍ 💾.

✋️ `open()` 🚫 ⚙️ `async` &amp; `await`.

, 👥 📣 🎉 🐕‍🦺 🔢 ⏮️ 🐩 `def` ↩️ `async def`.

///

/// info

👆 💪 ✍ 🌅 🔃 👫 🎉 🐕‍🦺 <a href="https://www.starlette.io/events/" class="external-link" target="_blank">💃 🎉' 🩺</a>.

///

### `startup` &amp; `shutdown` 👯‍♂️

📤 ↕ 🤞 👈 ⚛ 👆 *🕴* &amp; *🤫* 🔗, 👆 💪 💚 ▶️ 🕳 &amp; ⤴️ 🏁 ⚫️, 📎 ℹ &amp; ⤴️ 🚀 ⚫️, ♒️.

🔨 👈 👽 🔢 👈 🚫 💰 ⚛ ⚖️ 🔢 👯‍♂️ 🌅 ⚠ 👆 🔜 💪 🏪 💲 🌐 🔢 ⚖️ 🎏 🎱.

↩️ 👈, ⚫️ 🔜 👍 ↩️ ⚙️ `lifespan` 🔬 🔛.

## 📡 ℹ

📡 ℹ 😟 🤓. 👶

🔘, 🔫 📡 🔧, 👉 🍕 <a href="https://asgi.readthedocs.io/en/latest/specs/lifespan.html" class="external-link" target="_blank">🔆 🛠️</a>, &amp; ⚫️ 🔬 🎉 🤙 `startup` &amp; `shutdown`.

## 🎧 🈸

👶 ✔️ 🤯 👈 👫 🔆 🎉 (🕴 &amp; 🤫) 🔜 🕴 🛠️ 👑 🈸, 🚫 [🎧 🈸 - 🗻](sub-applications.md){.internal-link target=_blank}.
