# 🔬 🔗 ⏮️ 🔐

## 🔑 🔗 ⏮️ 🔬

📤 😐 🌐❔ 👆 💪 💚 🔐 🔗 ⏮️ 🔬.

👆 🚫 💚 ⏮️ 🔗 🏃 (🚫 🙆 🎧-🔗 ⚫️ 💪 ✔️).

↩️, 👆 💚 🚚 🎏 🔗 👈 🔜 ⚙️ 🕴 ⏮️ 💯 (🎲 🕴 🎯 💯), &amp; 🔜 🚚 💲 👈 💪 ⚙️ 🌐❔ 💲 ⏮️ 🔗 ⚙️.

### ⚙️ 💼: 🔢 🐕‍🦺

🖼 💪 👈 👆 ✔️ 🔢 🤝 🐕‍🦺 👈 👆 💪 🤙.

👆 📨 ⚫️ 🤝 &amp; ⚫️ 📨 🔓 👩‍💻.

👉 🐕‍🦺 5️⃣📆 🔌 👆 📍 📨, &amp; 🤙 ⚫️ 💪 ✊ ➕ 🕰 🌘 🚥 👆 ✔️ 🔧 🎁 👩‍💻 💯.

👆 🎲 💚 💯 🔢 🐕‍🦺 🕐, ✋️ 🚫 🎯 🤙 ⚫️ 🔠 💯 👈 🏃.

👉 💼, 👆 💪 🔐 🔗 👈 🤙 👈 🐕‍🦺, &amp; ⚙️ 🛃 🔗 👈 📨 🎁 👩‍💻, 🕴 👆 💯.

### ⚙️ `app.dependency_overrides` 🔢

👫 💼, 👆 **FastAPI** 🈸 ✔️ 🔢 `app.dependency_overrides`, ⚫️ 🙅 `dict`.

🔐 🔗 🔬, 👆 🚮 🔑 ⏮️ 🔗 (🔢), &amp; 💲, 👆 🔗 🔐 (➕1️⃣ 🔢).

&amp; ⤴️ **FastAPI** 🔜 🤙 👈 🔐 ↩️ ⏮️ 🔗.

{* ../../docs_src/dependency_testing/tutorial001.py hl[28:29,32] *}

/// tip

👆 💪 ⚒ 🔗 🔐 🔗 ⚙️ 🙆 👆 **FastAPI** 🈸.

⏮️ 🔗 💪 ⚙️ *➡ 🛠️ 🔢*, *➡ 🛠️ 👨‍🎨* (🕐❔ 👆 🚫 ⚙️ 📨 💲), `.include_router()` 🤙, ♒️.

FastAPI 🔜 💪 🔐 ⚫️.

///

⤴️ 👆 💪 ⏲ 👆 🔐 (❎ 👫) ⚒ `app.dependency_overrides` 🛁 `dict`:

```Python
app.dependency_overrides = {}
```

/// tip

🚥 👆 💚 🔐 🔗 🕴 ⏮️ 💯, 👆 💪 ⚒ 🔐 ▶️ 💯 (🔘 💯 🔢) &amp; ⏲ ⚫️ 🔚 (🔚 💯 🔢).

///
