# ⚙️ 📨 🔗

🆙 🔜, 👆 ✔️ 📣 🍕 📨 👈 👆 💪 ⏮️ 👫 🆎.

✊ 📊 ⚪️➡️:

* ➡ 🔢.
* 🎚.
* 🍪.
* ♒️.

&amp; 🔨, **FastAPI** ⚖ 👈 💽, 🏭 ⚫️ &amp; 🏭 🧾 👆 🛠️ 🔁.

✋️ 📤 ⚠ 🌐❔ 👆 💪 💪 🔐 `Request` 🎚 🔗.

## ℹ 🔃 `Request` 🎚

**FastAPI** 🤙 **💃** 🔘, ⏮️ 🧽 📚 🧰 🔛 🔝, 👆 💪 ⚙️ 💃 <a href="https://www.starlette.io/requests/" class="external-link" target="_blank">`Request`</a> 🎚 🔗 🕐❔ 👆 💪.

⚫️ 🔜 ⛓ 👈 🚥 👆 🤚 📊 ⚪️➡️ `Request` 🎚 🔗 (🖼, ✍ 💪) ⚫️ 🏆 🚫 ✔, 🗜 ⚖️ 📄 (⏮️ 🗄, 🏧 🛠️ 👩‍💻 🔢) FastAPI.

👐 🙆 🎏 🔢 📣 🛎 (🖼, 💪 ⏮️ Pydantic 🏷) 🔜 ✔, 🗜, ✍, ♒️.

✋️ 📤 🎯 💼 🌐❔ ⚫️ ⚠ 🤚 `Request` 🎚.

## ⚙️ `Request` 🎚 🔗

➡️ 🌈 👆 💚 🤚 👩‍💻 📢 📢/🦠 🔘 👆 *➡ 🛠️ 🔢*.

👈 👆 💪 🔐 📨 🔗.

{* ../../docs_src/using_request_directly/tutorial001.py hl[1,7:8] *}

📣 *➡ 🛠️ 🔢* 🔢 ⏮️ 🆎 ➖ `Request` **FastAPI** 🔜 💭 🚶‍♀️ `Request` 👈 🔢.

/// tip

🗒 👈 👉 💼, 👥 📣 ➡ 🔢 ⤴️ 📨 🔢.

, ➡ 🔢 🔜 ⚗, ✔, 🗜 ✔ 🆎 &amp; ✍ ⏮️ 🗄.

🎏 🌌, 👆 💪 📣 🙆 🎏 🔢 🛎, &amp; ➡, 🤚 `Request` 💁‍♂️.

///

## `Request` 🧾

👆 💪 ✍ 🌅 ℹ 🔃 <a href="https://www.starlette.io/requests/" class="external-link" target="_blank">`Request` 🎚 🛂 💃 🧾 🕸</a>.

/// note | 📡 ℹ

👆 💪 ⚙️ `from starlette.requests import Request`.

**FastAPI** 🚚 ⚫️ 🔗 🏪 👆, 👩‍💻. ✋️ ⚫️ 👟 🔗 ⚪️➡️ 💃.

///
