# Reference

Here's the reference or code API, the classes, functions, parameters, attributes, and
all the FastAPI parts you can use in your applications.

If you want to **learn FastAPI** you are much better off reading the
[FastAPI Tutorial](https://fastapi.tiangolo.com/tutorial/).
