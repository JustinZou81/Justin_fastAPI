# Learn

Here are the introductory sections and the tutorials to learn **FastAPI**.

You could consider this a **book**, a **course**, the **official** and recommended way to learn FastAPI. 😎
